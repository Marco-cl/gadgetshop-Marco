public class Gadget {
    private String model;
    private double price;
    private int weight;
    private String size;

    // Constructor for Gadget
    public Gadget(String model, double price, int weight, String size) {
        this.model = model;
        this.price = price;
        this.weight = weight;
        this.size = size;
    }

    // Accessor for model
    public String getModel() {
        return model;
    }

    // Accessor for price
    public double getPrice() {
        return price;
    }

    // Accessor for weight
    public int getWeight() {
        return weight;
    }

    // Accessor for size
    public String getSize() {
        return size;
    }

    // Display method for gadget details
    public String display() {
        return String.format("Type: Gadget\nModel: %s\nPrice: £%.2f\nWeight: %dg\nSize: %s\n",
                             model, price, weight, size);
    }
}
