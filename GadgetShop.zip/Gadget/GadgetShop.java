import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.util.ArrayList;
import javafx.scene.control.TextArea;


public class GadgetShop extends Application {
      private ArrayList<Gadget> gadgets = new ArrayList<>();
    private TextField modelField = new TextField();
    private TextField priceField = new TextField();
    private TextField weightField = new TextField();
    private TextField sizeField = new TextField();
    private TextField creditField = new TextField();
    private TextField memoryField = new TextField();
    private TextField phoneNumberField = new TextField();
    private TextField durationField = new TextField();
    private TextField downloadField = new TextField();
    private TextField displayNumberField = new TextField();
  private TextArea displayArea = new TextArea();
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Gadget Shop");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        
        // First Row
        grid.add(new Label("Model:"), 0, 0);
        grid.add(modelField, 0, 1);
        grid.add(new Label("Price:"), 1, 0);
        grid.add(priceField, 1, 1);
        grid.add(new Label("Weight:"), 2, 0);
        grid.add(weightField, 2, 1);
        grid.add(new Label("Size:"), 3, 0);
        grid.add(sizeField, 3, 1);
        
        // Second Row
        grid.add(new Label("Credit:"), 0, 2);
        grid.add(creditField, 0, 3);
        grid.add(new Label("Memory:"), 1, 2);
        grid.add(memoryField, 1, 3);
        
        // Button Grid
        GridPane buttonGrid = new GridPane();
        buttonGrid.setHgap(10);
        buttonGrid.setVgap(10);
        
        Button addMobileButton = new Button("Add Mobile");
        buttonGrid.add(addMobileButton, 0, 0);
        
        Button addMP3Button = new Button("Add MP3");
        buttonGrid.add(addMP3Button, 1, 0);
        
        Button clearButton = new Button("Clear");
        buttonGrid.add(clearButton, 0, 1);
        
        Button displayAllButton = new Button("Display All");
        buttonGrid.add(displayAllButton, 1, 1);
        
        


        grid.add(buttonGrid, 2, 2, 2, 2); // Span 2 columns and 2 rows for the button grid
        
        // Third Row
        grid.add(new Label("Phone No:"), 0, 4);
        grid.add(phoneNumberField, 0, 5);
        grid.add(new Label("Duration:"), 1, 4);
        grid.add(durationField, 1, 5);
        grid.add(new Label("Download:"), 2, 4);
        grid.add(downloadField, 2, 5);
        grid.add(new Label("Display Number:"), 3, 4);
        grid.add(displayNumberField, 3, 5);

        // Bottom Buttons
        Button makeCallButton = new Button("Make A Call");
        grid.add(makeCallButton, 0, 6);
        
        Button downloadMusicButton = new Button("Download Music");
        grid.add(downloadMusicButton, 1, 6);
        
       
         // Initialize the TextArea
        displayArea.setEditable(false);
        displayArea.setPrefHeight(200); // Set preferred height for the TextArea
        grid.add(displayArea, 0, 7, 8, 1); // Span 8 columns, update as necessary

        
        
        Scene scene = new Scene(grid); // Let the scene size be determined by the layout
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
              // Set button color to blue
        setButtonStyle(addMobileButton);
        setButtonStyle(addMP3Button);
        setButtonStyle(clearButton);
        setButtonStyle(displayAllButton);
        setButtonStyle(makeCallButton);
        setButtonStyle(downloadMusicButton);
        
        
        addMobileButton.setOnAction(event -> handleAddMobile());
        addMP3Button.setOnAction(event -> handleAddMP3());
        clearButton.setOnAction(event -> handleClear());
        displayAllButton.setOnAction(event -> handleDisplayAll());
        makeCallButton.setOnAction(event -> handleMakeCall());
        downloadMusicButton.setOnAction(event -> handleDownloadMusic());
        
    }
      private void setButtonStyle(Button button) {
       button.setStyle("-fx-background-color: #ADD8E6; -fx-text-fill: white;");

    }
      private void handleAddMobile() {
        try {
            String model = modelField.getText();
            double price = Double.parseDouble(priceField.getText());
            int weight = Integer.parseInt(weightField.getText());
            String size = sizeField.getText();
            int credit = Integer.parseInt(creditField.getText());
            Mobile mobile = new Mobile(model, price, weight, size, credit);
            gadgets.add(mobile);
            showAlert(AlertType.INFORMATION, "Success", "Mobile added successfully!");
            handleClear();
        } catch (NumberFormatException e) {
            showAlert(AlertType.ERROR, "Error", "Invalid input. Please enter valid numbers for price, weight, and credit.");
        }
    }

    private void handleAddMP3() {
        try {
            String model = modelField.getText();
            double price = Double.parseDouble(priceField.getText());
            int weight = Integer.parseInt(weightField.getText());
            String size = sizeField.getText();
            int memory = Integer.parseInt(memoryField.getText());
            MP3 mp3 = new MP3(model, price, weight, size, memory);
            gadgets.add(mp3);
            showAlert(AlertType.INFORMATION, "Success", "MP3 player added successfully!");
            handleClear();
        } catch (NumberFormatException e) {
            showAlert(AlertType.ERROR, "Error", "Invalid input. Please enter valid numbers for price, weight, and memory.");
        }
    }
    private void handleClear() {
        modelField.clear();
        priceField.clear();
        weightField.clear();
        sizeField.clear();
        creditField.clear();
        memoryField.clear();
        phoneNumberField.clear();
        durationField.clear();
        downloadField.clear();
        displayNumberField.clear();
    }
    // Method to display details of all gadgets
    private void handleDisplayAll() {
        StringBuilder displayText = new StringBuilder();
        for (Gadget gadget : gadgets) {
            displayText.append(gadget.display()).append("\n");
        }
        displayArea.setText(displayText.toString());
    }
    // Method to handle making a call
   private void handleMakeCall() {
    try {
        int displayNumber = Integer.parseInt(displayNumberField.getText());
        String phoneNumber = phoneNumberField.getText();
        int duration = Integer.parseInt(durationField.getText());

        if (displayNumber >= 0 && displayNumber < gadgets.size()) {
            Gadget gadget = gadgets.get(displayNumber);
            if (gadget instanceof Mobile) {
                Mobile mobile = (Mobile) gadget;
                if (mobile.getCredit() >= duration) {
                    mobile.makeCall(phoneNumber, duration);
                    displayArea.setText(mobile.display()); // Update TextArea with new details
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Insufficient credit to make the call.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Selected gadget is not a Mobile.");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid display number.");
        }
    } catch (NumberFormatException e) {
        showAlert(Alert.AlertType.ERROR, "Error", "Invalid input. Please enter valid numbers.");
    }
}
    // Code to simulate downloading music
  private void handleDownloadMusic() {
    try {
        int displayNumber = Integer.parseInt(displayNumberField.getText());
        int downloadSize = Integer.parseInt(downloadField.getText());

        if (displayNumber >= 0 && displayNumber < gadgets.size()) {
            Gadget gadget = gadgets.get(displayNumber);
            if (gadget instanceof MP3) {
                MP3 mp3 = (MP3) gadget;
                if (mp3.getMemory() >= downloadSize) {
                    mp3.downloadMusic(downloadSize);
                    displayArea.setText(mp3.display()); // Update TextArea with new details
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Insufficient memory for download.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Selected gadget is not an MP3 player.");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid display number.");
        }
    } catch (NumberFormatException e) {
        showAlert(Alert.AlertType.ERROR, "Error", "Invalid input. Please enter valid numbers.");
    } catch (IllegalStateException e) {
        showAlert(Alert.AlertType.ERROR, "Error", e.getMessage());
    }

}


    private boolean validateNumberInput(String input) {
        // Implement number validation logic, return true if valid
        try {
            Double.parseDouble(input);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    //Show ALerts
    // Helper method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
    }
    //Main Method
    public static void main(String[] args) {
        launch(args);
    }
}
