public class Mobile extends Gadget {
    private int credit;

    // Constructor for Mobile, extending Gadget
    public Mobile(String model, double price, int weight, String size, int credit) {
        super(model, price, weight, size);
        this.credit = credit;
    }

    // Adds calling credit
    public void addCredit(int amount) {
        if (amount > 0) {
            credit += amount;
        }
    }

    // Method to simulate making a call
    public void makeCall(String phoneNumber, int duration) {
        if (credit >= duration) {
            credit -= duration;
        }
    }
      // Method to get the current credit
    public int getCredit() {
        return credit;
    }

    // Overridden display method for mobile
    @Override
    public String display() {
        return String.format("Type: Mobile\n%sCredit: %d minutes\n",
                             super.display(), credit);
    }
}
