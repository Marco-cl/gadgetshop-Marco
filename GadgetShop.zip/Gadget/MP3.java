public class MP3 extends Gadget {
    private int memory;

    // Constructor for MP3, extending Gadget
    public MP3(String model, double price, int weight, String size, int memory) {
        super(model, price, weight, size);
        this.memory = memory;
    }

       // Method to simulate downloading music
    public void downloadMusic(int size) {
        if (size <= memory) {
            memory -= size;
        } else {
            throw new IllegalStateException("Insufficient memory for download.");
        }
    }

    // Get current memory
    public int getMemory() {
        return memory;
    }
    // Overridden display method for MP3
    @Override
    public String display() {
        return String.format("Type: MP3\n%sMemory: %dMB\n",
                             super.display(), memory);
    }
}
